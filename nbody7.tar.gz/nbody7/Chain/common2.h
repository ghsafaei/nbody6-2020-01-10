*        common2.h
*        ----------
*
       COMMON/CHAIN2/  Q(NMX4),CMX(3),ENERGY,P(NMX4),CMV(3),CHTIME
